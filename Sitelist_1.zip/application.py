import os
import numpy as np
import flask
import pickle
from flask import Flask, render_template, request
from flask_restful import Resource, Api
import io
import pandas as pd
from skcriteria import Data, MIN, MAX
import sys

application = app = Flask(__name__)
api = Api(app)

@app.route('/')
@app.route('/index2')
def index2():
    return flask.render_template('index2.html')

@app.route('/yindex', methods= ['GET','POST'])
def yindex():
    df = pd.read_csv(r'C:\Users\Rohan\.spyder-py3\IMP.csv')
    df_new= pd.concat([df['DAR On Target'],df['CTR'],df['Netflix Overlap'],df['APV Overlap'],df['Hotstar Overlap'],df['Desktop'],df['Mobile'],df['Avg_Min'],df['VTR']], axis=1).reset_index(drop=True)
    mtx = df_new
    criteria = [MAX,MAX,MAX,MAX,MAX,MAX,MAX,MAX,MAX]
    data = Data(mtx, criteria,
    weights = [0.22479564,0.10217984,0.06948229,0.13896458,0.09264305,0.055581832,0.083378748,0.13896458,0.06948229],
    anames= ['Car Dekho','Car Dekho',
             'CricBuzz', 'CricBuzz', 'CricBuzz',
             'Daily Hunt', 'Daily Hunt','Daily Hunt',
             'Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Facebook','Fa cebook','Facebook','Facebook','Facebook','Facebook','Facebook',
             'Hindustan Times', 'Hindustan Times','Hindustan Times','Hindustan Times','Hindustan Times','Hindustan Times','Hindustan Times','Hindustan Times',
             'iDiva', 'iDiva',
             'India Times','India Times','India Times','India Times','India Times','India Times',
             'Indian Express','Indian Express', 'Indian Express', 'Indian Express', 'Indian Express', 'Indian Express',
             'Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram','Instagram',
             'Ixigo','Ixigo',
             'Jansatta', 'Jansatta',
             'Live Mint','Live Mint',
             'Mens XP','Mens XP','Mens XP','Mens XP',
             'Money Control','Money Control',
             'NDTV','NDTV', 'NDTV', 'NDTV', 'NDTV', 'NDTV',
             'ScoopWhoop', 'ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop','ScoopWhoop',
             'The Hindu','The Hindu',
             'Times of India','Times of India', 'Times of India', 'Times of India', 'Times of India', 'Times of India', 'Times of India', 'Times of India', 'Times of India', 'Times of India',
             'True Caller',
             'Twitter','Twitter','Twitter','Twitter','Twitter','Twitter',
             'Voot','Voot',
             'YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube','YouTube',
             'Zig Wheels','Zig Wheels'],
    cnames=["DARTarget","CTR","Netflix Overlap","APV Overlap","HotStar Overlap","Comscore Desktop","Comscore Mobile","Avg Min","VTR"])
    from skcriteria.madm import closeness, simple
    fm = closeness.TOPSIS()
    gec = fm.decide(data)
    v = fm.solve(data)
    z = v[2]
    df['Rank_2'] = v[1]
    z = z.pop('closeness',None)
    df_C = pd.DataFrame.from_dict(z)
    df_new3 = pd.concat([df['Genre'], df['Age Group'], df['Gender'],df['Device'],df['Sitelist'],df['DAR On Target'],df['DAR_BotImpressions_%'],df['CTR'],df['VTR'],df['Netflix Overlap'],df['APV Overlap'],df['Hotstar Overlap'],df['Desktop'],df['Mobile'],df['Avg_Min'],df['Rank_2'],df_C],axis=1).reset_index(drop=True)
    if request.method == 'POST':
        list1 = flask.request.form.getlist('genre')
        list2 = flask.request.form.getlist('age')
        list3 = flask.request.form.getlist('gender')
        list4 = flask.request.form.getlist('device')


        #list3 = flask.request.form.getlist('age')
        #list4 = flask.request.form.getlist('gender')
        df_genre = df_new3[df_new3['Genre'].isin(list1) & df_new3['Age Group'].isin(list2) & df_new3['Gender'].isin(list3) & df_new3['Device'].isin(list4)].reset_index(drop=True)
        df_genre.sort_values('Rank_2', axis = 0, ascending = True, inplace = True, na_position ='first')

        #df_final['Percentage Allocation'] = df_final['output'].astype(str) + '%'
        #df_final = df_final.drop(['output'],axis=1)
        #list3 = list3.str.replace(r"[\"\',]", '')

        #a = list3[1]
        #b = list3[2]

       # df_genre = df[df['Input'].isin(list3)].reset_index(drop=True)
       # df_new= pd.concat([df_genre['DAR On Target'],df_genre['DAR_BotImpressions_%'],df_genre['APV Overlap '],df_genre['HotStar Overlap'],df_genre['Netflix ovelap '],df_genre['Comscore Desktop'],df_genre['Comscore_Mobile'],df_genre['CTR'],df_genre['VTR']], axis=1).reset_index(drop=True)
        #normalize_df=(df_new-df_new.min())/(df_new.max()-df_new.min())
        #b = normalize_df['DAR_BotImpressions_%']*0.045223385
        #c = normalize_df['APV Overlap ']*0.127817535
        #d = normalize_df['HotStar Overlap']*0.080523723
        #e = normalize_df['Netflix ovelap ']*0.076976845
        #f = normalize_df['Comscore_Desktop']*0.072256664
        #g = normalize_df['Comscore_Mobile']*0.108384996
        #h = normalize_df['CTR']*0.086969761
        #i = normalize_df['VTR']*0.086969761
        #normalize_df['Score'] = (b+c+d+e+f+g+h+i)*100
        #df_col = pd.concat([df_genre[' Sites'],normalize_df['Score'], df_genre['DAR On Target'],df_genre['DAR_BotImpressions_%'],df_genre['APV Overlap '],df_genre['HotStar Overlap'],df_genre['Netflix ovelap '],df_genre['Comscore Desktop'],df_genre['Comscore_Mobile'],df_genre['CTR'],df_genre['VTR']], axis=1).reset_index(drop=True)
        #df_col.sort_values("Score", axis = 0, ascending = False, inplace = True, na_position ='first')
        #example = df_col
        return render_template("ntest4.html", df_genre=df_genre.to_html())
    return render_template('ntest4.html')


if __name__ == '__main__':
   app.run(debug = True)
